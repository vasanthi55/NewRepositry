package com.cts.ProductManagment.controller;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
@Repository
public class ProductDao {


	@Autowired
	private DataSource ds;
	private JdbcTemplate jdbc;

	//Setter for JDBC Template
	public void setJdbc(JdbcTemplate jdbc) {
		this.jdbc = jdbc;
	}

	//Adding Product To Database
	public int addProduct(Product product){
		jdbc = new JdbcTemplate(ds);
		int storedStatus = jdbc.update("INSERT INTO product2 VALUES(?,?,?,?)", new Object[] {product.getProductId(),product.getProductName(),product.getProductQuantity(),product.getProductPrice()});
		System.out.println(storedStatus);
		return product.getProductId();
	}
	public Product getProductById(int prodId) {
		jdbc = new JdbcTemplate(ds);
		String sql = "SELECT * FROM product2 WHERE productId=?";
		Product product = (Product)jdbc.queryForObject(sql, new Object[] {prodId},

				new RowMapper<Product>() {
			@Override
            public Product mapRow(ResultSet rs, int rowNum) throws SQLException {
            Product product = new Product();

				product.setProductId(rs.getInt(1));
				product.setProductName(rs.getString(2));
				product.setProductQuantity(rs.getInt(3));
				product.setProductPrice(rs.getFloat(4));
				return product;
			}

		});
		return product;
	}
	

	//Delete Product by ID
	public int deleteProduct(int prodId) {
		jdbc = new JdbcTemplate(ds);
		int count = jdbc.update("DELETE FROM product2 WHERE productId=?", new Object[] {prodId});
		return count;
	}
	
	
	//Update Product Details by ID
	public int updateProduct(Product product, int prodId) {
		jdbc = new JdbcTemplate(ds);
		String sql1 = "UPDATE product2 SET productName=?, productQuantity=?, productPrice=? WHERE productId =?";
		int status = jdbc.update(sql1,new Object[] 
				{product.getProductName(),product.getProductQuantity(),product.getProductPrice(),product.getProductId()});
		return status;
	}



}
