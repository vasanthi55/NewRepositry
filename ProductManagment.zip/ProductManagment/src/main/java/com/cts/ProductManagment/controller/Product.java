package com.cts.ProductManagment.controller;

import org.springframework.stereotype.Component;

@Component
public class Product {
	
	
	private int productId;
	private String productName;
	private int productQuantity;
	private float productPrice;
	
	
	public Product() {
		
	}
	

	public Product(int prodId, String prodName, int prodQuantity, float prodPrice) {
	
		this.productId = prodId;
		this.productName = prodName;
		this.productQuantity = prodQuantity;
		this.productPrice = prodPrice;
	}


	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productQuantity="
				+ productQuantity + ", productPrice=" + productPrice + "]";
	}


	public int getProductId() {
		return productId;
	}


	public void setProductId(int productId) {
		this.productId = productId;
	}


	public String getProductName() {
		return productName;
	}


	public void setProductName(String productName) {
		this.productName = productName;
	}


	public int getProductQuantity() {
		return productQuantity;
	}


	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}


	public float getProductPrice() {
		return productPrice;
	}


	public void setProductPrice(float productPrice) {
		this.productPrice = productPrice;
	}

	

	
	
	
	

}

